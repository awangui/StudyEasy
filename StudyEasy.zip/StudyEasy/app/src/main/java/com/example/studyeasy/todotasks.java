package com.example.studyeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class todotasks extends AppCompatActivity {
   String todolist;
   String arrayAdapter;
    ListView listView;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todotasks);
        todolist = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this,R.layout.list_view_layout,todolist);
        listView = findViewById(R.id_list_view);
        listView.setAdapter(arrayAdapter);
        editText = findViewById(R.id_edit_text);

    }
    public void addTextToList(view view){
        todolist.add(editText.getText().toString());
        arrayAdapter.notifyDataSetChanged();
        editText.setText(' ');
    }
}