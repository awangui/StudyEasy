package com.example.studyeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Getting_started extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getting_started);
    }
}